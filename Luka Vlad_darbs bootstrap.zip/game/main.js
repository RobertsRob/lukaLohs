class Rocket {
	constructor() {
		this.horInput = 0; this.verInput = 0;
		this.speed = 20;
	} update(index) {
		if (keys.includes("a") && !keys.includes("d")) {this.horInput -= (this.horInput + 1) * time * 3;}
		else if (!keys.includes("a") && keys.includes("d")) {this.horInput += (-this.horInput + 1) * time * 3;}
		else {this.horInput -= this.horInput * time * 3;}
		if (this.horInput <= -0.999) {this.horInput = -1;} else if (abs(this.horInput) <= 0.001) {this.horInput = 0;} else if (this.horInput >= 0.999) {this.horInput = 1;}

		if (keys.includes("s") && !keys.includes("w")) {this.verInput -= (this.verInput + 1) * time * 3;}
		else if (!keys.includes("s") && keys.includes("w")) {this.verInput += (-this.verInput + 1) * time * 3;}
		else {this.verInput -= this.verInput * time * 3;}
		if (this.verInput <= -0.999) {this.verInput = -1;} else if (abs(this.verInput) <= 0.001) {this.verInput = 0;} else if (this.verInput >= 0.999) {this.verInput = 1;}
		
		hierarchy[1][0].horAngle += mouse[0] * sensitivity; hierarchy[1][0].verAngle -= mouse[1] * sensitivity;
		if (hierarchy[1][0].verAngle < -30) {hierarchy[1][0].verAngle = -30;}
		if (hierarchy[1][0].verAngle > 30) {hierarchy[1][0].verAngle = 30;}
		if (hierarchy[1][0].horAngle < 0) {hierarchy[1][0].horAngle += 360;}
		if (hierarchy[1][0].horAngle >= 360) {hierarchy[1][0].horAngle -= 360;}
		/**/

		for (let i = index; i < hierarchy.length; i++) {
			if (hierarchy[i][2] <= hierarchy[index][2] && i > index) {i = hierarchy.length;}
			else {
				hierarchy[i][0].x += this.speed * time * this.horInput;
				hierarchy[i][0].y += this.speed * time * this.verInput;
				hierarchy[i][0].z += this.speed * time;
			}
		}hierarchy[1][0].x = hierarchy[index][0].x - this.horInput*.5;
		hierarchy[1][0].y = hierarchy[index][0].y - this.verInput*.5;

		if (keys.includes("g")) {this.speed += time*550;}
		if (keys.includes("b")) {this.speed -= time*550;}
		hierarchy[2][0].text = Math.round(this.speed.toString()) + "km/s"
	} 
} class Engine {
	constructor(delay) {
		this.time = delay; this.delay = delay;
	} update(index) {
		this.time += time;
		if (this.time >= this.delay) {
			this.time = 0;
			let engine = hierarchy[index][0];
			hierarchy = hierarchy.slice(0, index + 1).concat([[new Sphere(engine.x, engine.y, engine.z, .05), new Particle(180+random(-8, 8), random(-8, 8)), hierarchy[index][2] + 1]], hierarchy.slice(index + 1));
		}
	}
} class Particle {
	constructor(horAngle, verAngle) {
		this.horAngle = horAngle; this.verAngle = verAngle;
		this.speed = 3.5;
	} update(index) {
		let particle = hierarchy[index][0];
		particle.x += this.speed * sin(this.horAngle) * cos(this.verAngle) * time;
		particle.y += this.speed * sin(this.verAngle) * time;
		particle.z += this.speed * cos(this.horAngle) * cos(this.verAngle) * time;
		particle.radius *= 0.985;
		if (particle.radius < 0.003) {hierarchy = hierarchy.slice(0, index).concat(hierarchy.slice(index+1));}
	}
} class Gun {
	constructor(cooldown) {
		this.time = cooldown; this.cooldown = cooldown;
	} update(index) {
		this.time += time;
		if (keys.includes(" ") && this.time >= this.cooldown) {
			this.time = 0;
			let gun = hierarchy[index][0];
			hierarchy.push([new Sphere(gun.x, gun.y, gun.z, .085), new Bullet(0), 0]);
		}
	}
} class Bullet {
	constructor(angle) {
		this.angle = angle;
		this.speed = 300;
		this.time = 0;
	} update(index) {
		let bullet = hierarchy[index][0];
		bullet.x += this.speed * time * sin(this.angle);
		bullet.z += this.speed * time * cos(this.angle);
		this.time += time;
		if (this.time >= 2) {hierarchy = hierarchy.slice(0, index).concat(hierarchy.slice(index+1));}
	}
}class Saturn {
	constructor(count) {
		this.count = count;
	} update(index) {
		let count = -1;
		for (let i = index + 1; i < hierarchy.length; i++) {
			if (hierarchy[i][2] > hierarchy[index][2]) {count++;}
			else {i = hierarchy.length;}
		} for (let i = count; i < this.count; i++) {
			let number = random(1415, 2380);
			let angle = random(0, 360);
			hierarchy = hierarchy.slice(0, index + 1).concat([[new Vertex(number * sin(angle) + hierarchy[index][0].x, number * sin(angle) * 0.2 + hierarchy[index][0].y, number * cos(angle) + hierarchy[index][0].z), null, hierarchy[index][2] + 1]], hierarchy.slice(index + 1));
		}
	}
}

function random(minimum, maximum) {return Math.random() * (maximum - minimum) + minimum;}
//----------------------------------------------------

let keys = [];
let mouse = [0, 0];
let time = new Date().getTime();
let hierarchy = [
	[new Vertex(0, 0, -3), new Rocket(), 0],
		[new Camera(0, 0, -11, 0, 0), null, 1],
		[new Vertex(0, -2, -5.2, ""), null, 1],
		[new Vertex(-2, -2, -7), new Engine(.165), 1],
		[new Vertex(-2, -2, -7), new Engine(.075), 1],
		[new Vertex(-2, -2, -7), new Engine(.065), 1],
		[new Vertex(1, -2, -5.2, "Q:No. E:Yes."), null, 1],
		[new Vertex(-2, -2, -7), new Engine(.025), 1],
			[new Box(-2, -2, -6.5, 0.75, 0.75, 1), null, 2],
			[new Box(-2, -2, -5, 1, 1, 2), null, 2],
			[new Box(-2, -2, -3.5, 0.7, 0.7, 1), null, 2],
			[new Vertex(-2, -2, -3), new Gun(.1), 2],
		[new Vertex(2, -2, -7), new Engine(.065), 1],
			[new Box(2, -2, -6.5, 0.75, 0.75, 1), null, 2],
			[new Box(2, -2, -5, 1, 1, 2), null, 2],
			[new Box(2, -2, -3.5, 0.7, 0.7, 1), null, 2],
			[new Vertex(2, -2, -3), new Gun(.1), 2],
		[new Vertex(0, -2, -5), null, 1],
			[new Box(-1, -2, -5, 1, 0.25, 0.25), null, 2],
			[new Box(0, -2, -5, 1, 0.25, 0.25), null, 2],
			[new Box(1, -2, -5, 1, 0.25, 0.25), null, 2],
			[new Box(-0.8, -2, -4.25, 0.175, 0.175, 1.25), null, 2],
			[new Box(0.65, -2, -4.25, 0.125, 0.125, 1.25), null, 2],
			[new Box(0.9, -2, -4.25, 0.125, 0.125, 1.25), null, 2],
			[new Box(-1.075, -2, -3.5, 1.15, 0.25, 0.25), null, 2],
			[new Box(0, -2, -3.5, 1, 0.25, 0.25), null, 2],
			[new Box(1.075, -2, -3.5, 1.15, 0.25, 0.25), null, 2],
		[new Vertex(0, 0, -7.5), null, 1],
	[new Box(2, -2, 50, 1, 2, 3), null, 0],
	[new Box(-12, 7, 150, 5, 2, 3), null, 0],
	[new Box(-12, 7, 350, 5, 2, 3), null, 0],
	[new Box(-12, 7, 850, 5, 2, 3), null, 0],
	[new Box(-12, 7, 1150, 5, 2, 3), null, 0],
	[new Vertex(4000, -499, 8000, "Saturn"), null, 0],
	[new Sphere(4000, -500, 8000, 1000), new Saturn(600), 0]
];
function main() {
	const canvas = document.getElementById("canvas");
	let width = window.innerWidth; let height = window.innerHeight;

	if (width * heightAspectRatio / widthAspectRatio <= height) {height = width * heightAspectRatio / widthAspectRatio;}
	else {width = height * widthAspectRatio / heightAspectRatio;}
	canvas.width = width; canvas.height = height;

	window.onkeydown = function(event) {
		let key = String.fromCharCode(event.keyCode).toLowerCase();
		if (!keys.includes(key)) {keys.push(key);}
	}; window.onkeyup = function(event) {
		let key = String.fromCharCode(event.keyCode).toLowerCase();
		if (keys.includes(key)) {keys = keys.slice(0, keys.indexOf(key)).concat(keys.slice(keys.indexOf(key) + 1));}
	}; window.onmousemove = function(event) {
		mouse = [event.movementX, event.movementY];
	}; window.onclick = function(event) {
		document.body.requestPointerLock();
		if (event.button === 0) {mouse.push("LMB");}
		else if (event.button === 1) {mouse.push("MMB");}
		else if (event.button === 2) {mouse.push("RMB");}
	}; time = (new Date().getTime() - time) * 0.001;

	for (let i = hierarchy.length - 1; i > -1; i--) {if (hierarchy[i][1] !== null) {hierarchy[i][1].update(i);}}

	let camera;
	let vertexes = [];
	let boxes = [];
	let spheres = [];
	for (let i = 0; i < hierarchy.length; i++) {
		if (hierarchy[i][0].constructor.name === "Camera") {camera = hierarchy[i][0];}
		else if (hierarchy[i][0].constructor.name === "Vertex") {vertexes.push(hierarchy[i][0]);}
		else if (hierarchy[i][0].constructor.name === "Box") {boxes.push(hierarchy[i][0]);}
		else if (hierarchy[i][0].constructor.name === "Sphere") {spheres.push(hierarchy[i][0]);}
	} time = new Date().getTime();

	let objects = vertexes.concat(boxes, spheres);
	let count = objects.length;
	for (let i = 0; i < count; i++) {
		let maximum = null;
		let index = null;
		for (let j = 0; j < objects.length; j++) {
			let number = distance(objects[j].getx() - camera.getx(), objects[j].gety() - camera.gety(), objects[j].getz() - camera.getz());
			if (maximum === null || number > maximum) {
				maximum = number;
				index = j;
			}
		} if (index !== null) {
			let angle = arctan(objects[index].getx() - camera.getx(), objects[index].getz() - camera.getz());
			if (angle < 0) {angle += 360;}
			angle -= camera.gethorAngle();
			if (angle <= -180) {angle += 360;} else if (angle > 180) {angle -= 360;}
			
			if (abs(angle) <= FOV) {objects[index].display(camera);}
			objects = objects.slice(0, index).concat(objects.slice(index + 1));
		}
	} mouse = [0, 0];
	requestAnimationFrame(main);
} requestAnimationFrame(main);