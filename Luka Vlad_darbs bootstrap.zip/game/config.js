const pi = 3.14159265;
function abs(number) {if (number < 0) {return -number;} return number;}
function sqr(number) {return number * number;}
function sqrt(number) {return Math.sqrt(number);}
function pythagoras(width, height) {return sqrt(sqr(width) + sqr(height));}
function distance(width, height, length) {return pythagoras(pythagoras(width, height), length);}
function deg(angle) {return angle / pi * 180;}
function rad(angle) {return angle * pi / 180;}
function sin(angle) {return Math.sin(rad(angle));}
function cos(angle) {return Math.cos(rad(angle));}
function arctan(width, height) {return deg(Math.atan2(width, height));}

const widthAspectRatio = 16;
const heightAspectRatio = 9;
const FOV = 60;
const sensitivity = 0.1;