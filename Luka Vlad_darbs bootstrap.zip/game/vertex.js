class Vertex {
	constructor(x, y, z, text = "") {
		this.x = x; this.y = y; this.z = z;
		this.text = text;
	} display(camera) {
		camera.displayVertex(this.x, this.y, this.z, this.text);
	} getx() {return this.x;} gety() {return this.y;} getz() {return this.z;}
}