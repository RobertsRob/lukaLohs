class Camera {
	constructor(x, y, z, horAngle, verAngle) {
		this.x = x; this.y = y; this.z = z;
		this.horAngle = horAngle; this.verAngle = verAngle;
		this.canvas = document.getElementById("canvas"); this.tool = this.canvas.getContext("2d");
	} getxOnCanvas(x, z) {
		let horAngle = arctan(x - this.x, z - this.z);
		if (horAngle < 0) {horAngle += 360;}
		let clockwiseAngle = horAngle - this.horAngle;
		if (clockwiseAngle < 0) {clockwiseAngle += 360;}
		let counterclockwiseAngle = 360 - clockwiseAngle;

		if (clockwiseAngle >= counterclockwiseAngle) {return 0.5 - counterclockwiseAngle / FOV;}
		return 0.5 + clockwiseAngle / FOV;
	} getyOnCanvas(x, y, z) {
		let verAngle = arctan(y - this.y, pythagoras(x - this.x, z - this.z)) - this.verAngle;
		return 0.5 - verAngle / FOV * widthAspectRatio / heightAspectRatio;
	} displayVertex(x, y, z, text = "") {
		let xOnCanvas = this.canvas.width * this.getxOnCanvas(x, z);
		let yOnCanvas = this.canvas.height * this.getyOnCanvas(x, y, z);

		this.tool.lineWidth = 2; this.tool.strokeStyle = "#ffffff"; this.tool.fillStyle = "#ffffff"; this.tool.font = "16px Consolas"; this.tool.textAlign = "center";
		this.tool.beginPath();
		this.tool.arc(xOnCanvas, yOnCanvas, 1, 0, pi * 2)
		if (text !== "") {
			this.tool.moveTo(xOnCanvas, yOnCanvas);
			this.tool.lineTo(xOnCanvas - 5, yOnCanvas - 5);
			this.tool.lineTo(xOnCanvas - text.length * 4.5 - 3, yOnCanvas - 5);
			this.tool.moveTo(xOnCanvas, yOnCanvas);
			this.tool.lineTo(xOnCanvas + 5, yOnCanvas - 5);
			this.tool.lineTo(xOnCanvas + text.length * 4.5 + 3, yOnCanvas - 5);
			this.tool.fillText(text, xOnCanvas, yOnCanvas - 10);
		} this.tool.stroke();
	} displayPolygon(vertexes) {
		this.tool.lineWidth = 2; this.tool.strokeStyle = "#ffffff"; this.tool.fillStyle = "#000000";
		this.tool.beginPath();
		this.tool.moveTo(this.canvas.width * this.getxOnCanvas(vertexes[vertexes.length - 1][0], vertexes[vertexes.length - 1][2]), this.canvas.height * this.getyOnCanvas(vertexes[vertexes.length - 1][0], vertexes[vertexes.length - 1][1], vertexes[vertexes.length - 1][2]));
		for (let i = 0; i < vertexes.length; i++) {this.tool.lineTo(this.canvas.width * this.getxOnCanvas(vertexes[i][0], vertexes[i][2]), this.canvas.height * this.getyOnCanvas(vertexes[i][0], vertexes[i][1], vertexes[i][2]));}
		this.tool.fill();
		this.tool.stroke();
	} displaySphere(x, y, z, radius) {
		let xOnCanvas = this.canvas.width * this.getxOnCanvas(x, z);
		let yOnCanvas = this.canvas.height * this.getyOnCanvas(x, y, z);
		let number = distance(x - this.x, y - this.y, z - this.z);

		this.tool.lineWidth = 2; this.tool.strokeStyle = "#ffffff"; this.tool.fillStyle = "#000000";
		this.tool.beginPath();
		this.tool.arc(xOnCanvas, yOnCanvas, this.canvas.width * radius / number, 0, pi * 2);
		this.tool.fill();
		this.tool.stroke();
	} sethorAngle(horAngle) {this.horAngle = horAngle;} setverAngle(verAngle) {this.verAngle = verAngle;}
	getx() {return this.x;} gety() {return this.y;} getz() {return this.z;}
	gethorAngle() {return this.horAngle;} getverAngle() {return this.verAngle;}
}