class Sphere {
	constructor(x, y, z, radius) {
		this.x = x; this.y = y; this.z = z;
		this.radius = radius;
	} display(camera) {
		camera.displaySphere(this.x, this.y, this.z, this.radius);
	} getx() {return this.x;} gety() {return this.y;} getz() {return this.z;}
}